const express = require("express");
const bodyParser = require('body-parser');
const cors = require('cors');
const app = express();
const mysql = require("mysql");

const db = mysql.createPool({
    host: "localhost",
    user: "root",
    password: "password",
    database: "supplierdb",
    insecureAuth : true
})

app.use(cors());
app.use(express.json());
app.use(bodyParser.urlencoded({extended: true}));


app.post("/api/get",(req,res)=>{
    const companyName = req.body.companyName;
    console.log(companyName);
        const sqlInsert = `SELECT * FROM supplierdb.companies WHERE Name= '${companyName}';`
        db.query(sqlInsert , (err, result)=>{
            res.send(result);
        })
    })



app.post("/api/insert",(req,res)=>{

const companyName = req.body.companyName;
const telephone = req.body.telephone;

    const sqlInsert = "INSERT INTO supplierdb.companies (Name,TelephoneNo) VALUES (?,?);"
    db.query(sqlInsert ,[companyName , telephone], (err, result)=>{
        console.log(result);
    })
})
app.listen(3001, ()=>{
    console.log("running on port 3001")
})