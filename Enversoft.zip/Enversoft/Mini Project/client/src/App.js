import { useState } from "react";
import Axios from "axios";
import "./App.css";

function App() {
  const [companyName, setCompanyName] = useState("");
  const [telephone, setTelephone] = useState("");
  const [show, setShow] = useState(true);
  const[companyList,setCompanyList]= useState([])


  const submitCompany = () => {
    Axios.post("http://localhost:3001/api/insert", {
      companyName: companyName,
      telephone: telephone,
    }).then(() => {
      alert("sucessful insert");
    });
  };

  const findCompany = () => {
    Axios.post("http://localhost:3001/api/get", {
      companyName: companyName
    }).then((response) => {
      setCompanyList(response.data)
    });
  };

  return (
    <div className="App">
      <h1>Supplier database</h1>

      {show ? (
        <div>
          <button
            onClick={() => {
              setShow(!show);
            }}
          >
            Find Supplier
          </button>
          <div className="form">
            <label>Company Name</label>
            <input
              type="text"
              name="company"
              onChange={(e) => {
                setCompanyName(e.target.value);
              }}
            />
            <label>Telephone</label>
            <input
              type="text"
              name="telephone"
              onChange={(e) => {
                setTelephone(e.target.value);
              }}
            />

            <button onClick={submitCompany}>submit</button>
          </div>
        </div>
      ) : (
        <div>
          <button
            onClick={() => {
              setShow(!show);
            }}
          >
            Add Supplier
          </button>
          <div className="form">
            <label>Company Name</label>
            <input 
            type="text" 
            name="company"
            onChange={(e) => {
              setCompanyName(e.target.value);
            }}
            
            />

            <button onClick={findCompany}>Search</button>


            {companyList.map((val)=>{
              return <h3>Company Name: {val.Name} | Telephone: {val.TelephoneNo}</h3>
            })}
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
