package enversoft;
import java.util.*;
public class Exercise3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Integer[] list1 = { 1, 2, 3, 4, 5 };
        Integer[] list2 = { 3, 4, 5, 6, 7 };
        List<Integer> targetList = Arrays.asList(list1);
        for (int i = 0; i < list2.length; i++) {
       boolean contains = targetList.contains(list2[i]);
        
       if(!contains){
        System.out.println(list2[i]);
       }
     }
	}

}
