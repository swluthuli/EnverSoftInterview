package enversoft;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;

import java.io.PrintWriter;
import java.util.*;

import static java.util.stream.Collectors.*;


/**
 * @author Welcome
 *
 */
public class Exercise4 {

	public static void main(String[] args) {
		// Path CSV file, separator and container for data
		String csvFile = "C:\\Users\\probook\\eclipse-workspace\\InterviewTest\\lib\\Data.csv";
		String line = "";
		String cvsSplitBy = ",";
		List<String> list = new ArrayList<String>();

		// Pulling csv data
		try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
			br.readLine();
			while ((line = br.readLine()) != null) {

				// use comma as separator
				String[] data = line.split(cvsSplitBy);
				list.add(data[2]);

			}
			// Removing duplicates to not count the same element twice
			//Set<String> noDuplicates = new HashSet<String>(list);
			List<String> listOfAddresses = new ArrayList<String>(list);
			Map<String, String> Address = new HashMap<>();
			
			//Collections.sort(listOfAddresses);
			
			//Getting the frequency of words
			for (String key : listOfAddresses) {
				Address.put(key.split(" ", 2)[0], key.split(" ", 2)[1]);

			}
			//System.out.println(people);
			//Sort the list by value
			
			 Map<String, String> sorted = Address
				        .entrySet()
				        .stream()
				        .sorted(Map.Entry.<String, String>comparingByValue())
				        .collect(
				            toMap(e -> e.getKey(), e -> e.getValue(), (e1, e2) -> e2,
				                LinkedHashMap::new));

System.out.println(sorted);
			
			
			
/*
 * Map<String, String> sorted =
 * Address.entrySet().stream().sorted(comparingByValue()).collect(toMap(e ->
 * e.getKey(), e -> e.getValue(), (e1, e2) -> e2, LinkedHashMap::new));
 */
			  
			  //Writing to file 
				
				  File Execise5 = new File("Execise5.txt"); FileOutputStream fos = new
				  FileOutputStream(Execise5); PrintWriter pw = new PrintWriter(fos);
				  
				  for (Map.Entry<String, String> m : sorted.entrySet()) {
				  pw.println(m.getKey() + " " + m.getValue()); }
				  
				  pw.flush(); pw.close(); fos.close();
				 

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
