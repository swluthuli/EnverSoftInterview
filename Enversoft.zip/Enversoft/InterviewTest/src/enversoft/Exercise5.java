package enversoft;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;

import java.io.PrintWriter;
import java.util.*;

import static java.util.stream.Collectors.*;

/**
 * @author Welcome
 *
 */
public class Exercise5 {

	public static void main(String[] args) {
		// Path CSV file, separator and container for data
		String csvFile = "C:\\Users\\probook\\eclipse-workspace\\InterviewTest\\lib\\Data.csv";
		String line = "";
		String cvsSplitBy = ",";
		List<String> list = new ArrayList<String>();

		// Pulling csv data
		try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
			br.readLine();
			while ((line = br.readLine()) != null) {

				// use comma as separator
				String[] data = line.split(cvsSplitBy);
				list.add(data[1]);

			}
			// Removing duplicates to not count the same element twice
			Set<String> noDuplicates = new HashSet<String>(list);
			List<String> listOfNames = new ArrayList<String>(noDuplicates);
			Map<String, Integer> people = new HashMap<>();
			
			Collections.sort(listOfNames);
			
			//Getting the frequency of words
			for (String key : listOfNames) {
				people.put(key, Collections.frequency(list, key));

			}
			//Sort the list by value
			Map<String, Integer> sorted = people.entrySet().stream()
					.sorted(Collections.reverseOrder(Map.Entry.comparingByValue()))
					.collect(toMap(e -> e.getKey(), e -> e.getValue(), (e1, e2) -> e2, LinkedHashMap::new));
			
			//Writing to file
			File Execise4 = new File("Execise4.txt");
			FileOutputStream fos = new FileOutputStream(Execise4);
			PrintWriter pw = new PrintWriter(fos);

			for (Map.Entry<String, Integer> m : sorted.entrySet()) {
				pw.println(m.getKey() + "," + m.getValue());
			}

			pw.flush();
			pw.close();
			fos.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
